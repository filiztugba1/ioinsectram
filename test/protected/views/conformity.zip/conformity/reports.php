<?php
User::model()->login();
$ax= User::model()->userobjecty('');

$exel='';

	if($ax->firmid>0)
	{
		$exel=Firm::model()->find(array('condition'=>'id='.$ax->firmid))->name;
		if($ax->branchid>0)
		{
			$exel=$exel.' > '.Firm::model()->find(array('condition'=>'id='.$ax->branchid))->name;
			if($ax->clientid>0)
			{
				$exel=$exel.' > '.Client::model()->find(array('condition'=>'id='.$ax->clientid))->name;
				if($ax->clientbranchid>0)
				{
					$exel=$exel.' > '.Client::model()->find(array('condition'=>'id='.$ax->clientbranchid))->name;
					$where="clientid=".$ax->clientbranchid;
					
					
				}
				else
				{					
					$where="clientid in (".implode(',',Client::model()->getbranchids($ax->clientid)).")";
		
					/*	$workorder=Client::model()->findAll(array('condition'=>'parentid='.$ax->clientid));
						$i=0;
						foreach($workorder as $workorderx)
						{
							if($i==0)
							{
								$where='clientid='.$workorderx->id;
							}
							else
							{
							$where=$where.' or clientid='.$workorderx->id;
							}
											
						}*/
					
					
				}
			}
			else
			{
				$where="firmbranchid=".$ax->branchid;
			}
		}
		else
		{
			$where="firmid in (".implode(',',Firm::model()->getbranchids($ax->firmid)).")";
		}


		$where=$where." and endofdayemail=0";
		
	}
	else
	{
		$where="endofdayemail=0";
	}


if(isset($_POST['Reports']['firmid']) && $_POST['Reports']['firmid']!='')
{
	$exel=Firm::model()->find(array('condition'=>'id='.$_POST['Reports']['firmid']))->name;
	$where="firmid in (".implode(',',Firm::model()->getbranchids($_POST['Reports']['firmid'])).")";
}

if(isset($_POST['Reports']['branchid']) && $_POST['Reports']['branchid']!='')
{
	$exel=$exel.' > '.Firm::model()->find(array('condition'=>'id='.$_POST['Reports']['branchid']))->name;

	$where="firmbranchid=".$_POST['Reports']['branchid'];
}


if(isset($_POST['Reports']['clientid']) && $_POST['Reports']['clientid']!='')
{
	$clb=Client::model()->find(array('condition'=>'id='.$_POST['Reports']['clientid']));
	$cl=Client::model()->find(array('condition'=>'id='.$clb->parentid));
	
	$exel=$exel.' > '.$cl->name.' > '.$clb->name;
	
	$where="clientid=".$_POST['Reports']['clientid'];
}






if(isset($_POST['Reports']['type']) && $_POST['Reports']['type']!=-1)
{
	
	$statussql='';
	$statusexel='';

	for($i=0;$i<count($_POST["Reports"]["type"]);$i++)
	{
		$stname=Conformitystatus::model()->find(array('condition'=>'id='.$_POST["Reports"]["type"][$i]));
		if($i==0)
		{
			$statussql='statusid='.$_POST["Reports"]["type"][$i];
			$statusexel=$stname->name;
		}
		else
		{
			$statussql=$statussql.' or statusid='.$_POST["Reports"]["type"][$i];
			$statusexel=$statusexel.','.$stname->name;
		}

		
		$exel=$exel.' ( '.t("Status").'='.$statusexel.')';
		
	}

	$where= $where." and (".$statussql.')';

}

if(isset($_POST['Reports']['startdate'])) 
{
	$midnight = strtotime("today", strtotime($_POST['Reports']['startdate']));
	$where= $where." and date>=".$midnight;

	$exel=$exel.'( '.t("Start Date").'='.$_POST['Reports']['startdate'].')';
}

if(isset($_POST['Reports']['finishdate'])) 
{
	$midnight2 = strtotime("today", strtotime($_POST['Reports']['finishdate'])+3600*24);
	$where= $where." and date<=".$midnight2;

	$exel=$exel.'( '.t("Finish Date").'='.$_POST['Reports']['finishdate'].')';
}
//echo $where;




		$conformity=Conformity::model()->findAll(array('condition'=>$where,'order'=>'statusid asc'));


$yetki=1;

if($ax->mainclientbranchid!=$ax->clientbranchid)
{
	$yetki=0;
}
	


?>

<?php if (Yii::app()->user->checkAccess('nonconformitymanagement.view')){ ?>	
	<!-- Sayfada neredeyiz -->
<?=User::model()->geturl('Conformity','',0,'conformity');?>

	<div  id='reports'>
		
			<div class="card">
				     <div class="card-header">
						 <div class="row" style="padding-bottom: 10px;border-bottom: 1px solid #f8f8f9;">
							 <div class="col-md-6">
								  <h4  class="card-title"><?=t('Search Conformity Report');?></h4>
									</div>
									 <div class="col-md-6">
								<button id="cancel" class="btn btn-danger btn-xs" style="float:right" type="submit"><i class="fa fa-times"></i></button>
								</div>	
						</div>
					 </div>
				 
				<form id="conformity-form" action="/conformity/reports"  method="post" enctype="multipart/form-data">		
				<div class="card-content">
					<div class="card-body">
					
					
					<div class="row">
					
						<?
						$col='col-xl-4 col-lg-4 col-md-4 mb-1';
							
						if($ax->firmid!=0 && $ax->branchid!=0){
							$col='col-xl-6 col-lg-6 col-md-6 mb-1';
						}?>

						<?if($ax->firmid==0){?>
						<div class="<?=$col;?>">
							<label for="basicSelect"><?=t('Firm');?></label>
							<fieldset class="form-group">
								<select class="select2" style="width:100%" id="firm" name="Reports[firmid]" onchange="myfirm()" >
									<option value="0"><?=t('Please Chose');?></option>
									<?
									$firm=Firm::model()->findall(array('condition'=>'parentid=0'));
									 foreach($firm as $firmx){?>
									<option <?if(isset($_POST['Reports']['firmid']) &&$firmx->id==$_POST['Reports']['firmid']){echo "selected";}?> value="<?=$firmx->id;?>"><?=$firmx->name;?></option>
									 <?}?>
								</select>
							</fieldset>
						</div>
						<?}else{?>
							<input type="hidden" class="form-control" id="firm" name="Reports[firmid]" value="<?=$ax->firmid;?>" >
						<?}?>
						
						<?if($ax->branchid==0){?>
						<div class="<?=$col;?>">
						<label for="basicSelect"><?=t('Branch');?></label>
							<fieldset class="form-group">
								<select class="select2" style="width:100%" id="branch" name="Reports[branchid]" onchange="mybranch()" <?if(!isset($_POST['Reports']['branchid'])){echo 'disabled';}?> >
									<option value="0"><?=t("Please Choose")?></option>
									
									<?
									if($workorder->firmid!=0){
									$branch=Firm::model()->findall(array('condition'=>'parentid='.$workorder->firmid));
									 foreach($branch as $branchx){?>
									<option <?if(isset($_POST['Reports']['branchid']) &&$branchx->id==$_POST['Reports']['branchid']){echo "selected";}?> value="<?=$branchx->id;?>"><?=$branchx->name;?></option>
									<?}}?>
								</select>
							</fieldset>
						</div>
						<?}else{?>
							<input type="hidden" class="form-control" id="branch" name="Reports[branchid]" value="<?=$ax->branchid;?>" requred>
						<?}?>
					
					<?if($ax->clientbranchid==0){?>					
					<div class="<?=$col;?>">
					<label for="basicSelect"><?=t('Client');?></label>
                        <fieldset class="form-group">
						
                          <select class="select2" style="width:100%" id="client" name="Reports[clientid]" <?if(!isset($_POST['Reports']['clientid'])){echo 'disabled';}?>   onchange="myFunctionClient()">
								<option value="0"><?=t("Select");?></option>
								<?
								if($workorder->branchid!=0){
								$client=Client::model()->findall(array('condition'=>'parentid=0 and firmid='.$workorder->branchid));
								
									foreach($client as $clientx)
										{?>
											<optgroup label="<?=$clientx->name;?>">
												<?$clientbranchs=Client::model()->findAll(array('condition'=>'parentid='.$clientx->id));
													
													foreach($clientbranchs as $clientbranch)
													{?>
														<option <?if(isset($_POST['Reports']['clientid'])&& $clientbranch->id==$_POST['Reports']['clientid']){echo "selected";}?> value="<?=$clientbranch->id;?>"><?=$clientbranch->name;?></option>
													<?}?>
											</optgroup>
								<?}}?>
							</select>
                        </fieldset>
                    </div>
					<?}else{?>
							<input type="hidden" class="form-control" id="client" name="Reports[clientid]" value="<?=$ax->clientbranchid;?>" requred>
					<?}?>


					<div class="<?=$col;?>">
						<label for="basicSelect"><?=t('Status');?></label>
							<fieldset class="form-group">
								<select class="select2-placeholder-multiple form-control" multiple="multiple" style="width:100%" name="Reports[type][]">
									<option value=""><?=t('Select');?></option>

									<?$status=Conformitystatus::model()->findall();
									foreach($status as $statusx)
									{?>
										<option <?
										if(isset($_POST['Reports']['type']) && Workorder::model()->isnumber($statusx->id,Workorder::model()->msplit($_POST['Reports']['type']))){echo "selected";}?> value="<?=$statusx->id;?>"><?=t($statusx->name);?></option>
									<?}?>
								</select>
							</fieldset>
					</div>

					
					
					

					<div class="<?=$col;?>">
                        <fieldset class="form-group">
						<label for="basicSelect"><?=t('Start Date');?></label>
                          <input type="date"  class="form-control"  placeholder="<?=t('Start Date');?>" name="Reports[startdate]" value="<?if(isset($_POST['Reports']['startdate'])){echo $_POST['Reports']['startdate'];}else{echo date('Y-m-d');}?>">
                        </fieldset>
                    </div>

					<div class="<?=$col;?>">
                        <fieldset class="form-group">
						<label for="basicSelect"><?=t('Finish Date');?></label>
                          <input type="date"  class="form-control"  placeholder="<?=t('Finish Date');?>" name="Reports[finishdate]" value="<?if(isset($_POST['Reports']['startdate'])){echo $_POST['Reports']['finishdate'];}else{echo date('Y-m-d');}?>">
                        </fieldset>
                    </div>
				
				


				
				
					  	<div class="col-xl-12 col-lg-12 col-md-12 mb-1">
                        <fieldset class="form-group">
                        <div class="input-group-append" id="button-addon2" style="float:right">
									<button class="btn btn-primary block-page" type="submit"><?=t('Search');?></button>
								</div>
                        </fieldset>
                    </div>
					  </div>
				
						
						
					</div>
				</div>
				</form>
			</div>
		
	</div><!-- form -->


	 <!-- HTML5 export buttons table -->
        <section id="html5">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-header">
					<div class="row" style="border-bottom: 1px solid #e3ebf3;">
					   <div class="col-xl-6 col-lg-9 col-md-9 mb-1">
						 <h4 class="card-title"><?=t('REPORTS');?></h4>
						</div>

						<div class="col-xl-6 col-lg-9 col-md-9 mb-1 text-right" >
							<a style='color:#fff;float:right;text-align:right;margin-left:3px' class="btn btn-info" id="reportbutton" type="submit"><?=t('Search Reports');?> <i class="fa fa-file"></i></a>

							<!--<?if($yetki==1){?>
							<a style='color:#fff;float:right;text-align:right;margin-left:3px' class="btn btn-warning" id="printbutton" type="submit"><?=t('Print');?> <i class="fa fa-print"></i></a>
							<?}?>

							-->
						</div>

						

						

					</div>
                </div>
				
                <div class="card-content collapse show">
                  <div class="card-body card-dashboard">
                  
                      <table class="table table-striped table-bordered dataex-html5-export table-responsive">
                        <thead>
                          <tr>
					
							<th><?=t('WHO');?></th>
                            <th><?=t('TO WHO');?></th>
                            <th><?=t('DEPARTMENT');?></th>
                            <th><?=t('SUB-DEPARTMENT');?></th>
                            <th><?=t('OPENING DATE');?></th>
                            <th><?=t('TYPE');?></th>
                            <th><?=t('DEFINITION');?></th>
                            <th><?=t('SUGGESTION');?></th>
                            <th><?=t('STATUS');?></th>
                            <th><?=t('PRIORITY');?></th>
							<th><?=t('DEADLINE');?></th>
							<th><?=t('CLOSED TIME');?></th>
							<th><?=t('ACTIVITY STATUS');?></th>
							
                          </tr>
                        </thead>
                        <tbody>
                         
                     
					 		<?php
							foreach($conformity as $conformityx){
							$deadline=Conformityactivity::model()->find(array('condition'=>'conformityid='.$conformityx->id));
							$effincy=Efficiencyevaluation::model()->find(array('condition'=>'conformityid='.$conformityx->id));
							if($effincy)
							{
								$eff=$effincy->controldate;
							}
							else{
								$eff="No";
							}
								if($deadline)
								{
									$deadt=$deadline->date;
								}
								else{
									$deadt="-";
								}
							$depart=Departments::model()->find(array('condition'=>'id='.$conformityx->departmentid,));
							if ($depart){ $depart=$depart->name;
							$subdep=Departments::model()->find(array('condition'=>'id='.$conformityx->subdepartmentid,))->name;
							}else{
							$depart='-';
							$subdep='-';
							
							}
							if($conformityx->closedtime!='')
								{
									$kpnma=date('Y-m-d',$conformityx->closedtime);
								}
								else{
									$kpnma="-";
								}

								?> 
							<tr>
							
								 <td><?$username=User::model()->find(array('condition'=>'id='.$conformityx->userid));
								 echo $username->name.' '.$username->surname;
								 
								 ?></td>
								 <td><?=Client::model()->find(array('condition'=>'id='.$conformityx->clientid))->name;?></td>
					<td><?=$depart?></td>
								 <td><?=$subdep?></td>
								 <td>
								 <?=date('Y-m-d',$conformityx->date);?>
								 <td><?=t(Conformitytype::model()->find(array('condition'=>'id='.$conformityx->type,))->name);?></td>
								
									 <?//explode(' ',Generalsettings::model()->dateformat($conformityx->date))[0];?></td>
								
								 <td><?=$conformityx->definition?></td> <!-- sorun -->
								 <td><?=$conformityx->suggestion?></td> <!-- öneri -->
								 <td><?=t(Conformitystatus::model()->find(array('condition'=>'id='.$conformityx->statusid,))->name);?></td>
								
								<td><?=$conformityx->priority?><?=t('st Degree');?></td>  <!-- priority -->
								<td><?=$deadt?></td>  <!-- Deadline -->
								<td><?=$kpnma?></td>
								<td><?=t($eff);?></td>	
					
                       </tr>
						<?}?>
						 
                        </tbody>
                        <tfoot>
                          <tr>
						  
							<th><?=t('WHO');?></th>
                            <th><?=t('TO WHO');?></th>
                            <th><?=t('DEPARTMENT');?></th>
                            <th><?=t('SUB-DEPARTMENT');?></th>
                            <th><?=t('OPENING DATE');?></th>
                            <th><?=t('TYPE');?></th>
                            <th><?=t('DEFINITION');?></th>
                            <th><?=t('SUGGESTION');?></th>
                            <th><?=t('STATUS');?></th>
                            <th><?=t('PRIORITY');?></th>
							<th><?=t('DEADLINE');?></th>
							<th><?=t('CLOSED TIME');?></th>
							<th><?=t('ACTIVITY STATUS');?></th>
                          </tr>
                        </tfoot>
                      </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <!--/ HTML5 export buttons table -->

<?php if (Yii::app()->user->checkAccess('nonconformitymanagement.update')){ ?>
<!-- GÜNCELLEME BAŞLANGIÇ-->		
	<div class="col-lg-4 col-md-6 col-sm-12">
        <div class="form-group">
                           <!-- Modal -->
            <div class="modal fade text-left" id="duzenle" tabindex="-1" role="dialog" aria-labelledby="myModalLabel8"
                          aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header bg-warning white">
                            <h4 class="modal-title" id="myModalLabel8"><?=t('Non-Conformity Management Update');?></h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
                            </button>
                        </div>
						
					<!--form baslangıç-->						
				<form id="conformity-form2" action="/conformity/update/0" method="post" enctype="multipart/form-data">	
                     <div class="modal-body">
					 <input type="hidden" class="form-control" id="modalid" name="Conformity[id]" value="0">





					 

						<?if($ax->firmid==0){?>
						<div class="col-xl-12 col-lg-12 col-md-12 mb-1">
							<label for="basicSelect"><?=t('Firm');?></label>
							<fieldset class="form-group">
								<select class="select2" style="width:100%" id="firm2" name="Conformity[firmid]" onchange="myfirm2()" requred>
									<option value="0"><?=t('Please Chose');?></option>
									<?
									$firm=Firm::model()->findall(array('condition'=>'parentid=0'));
									 foreach($firm as $firmx){?>
									<option <?if($firmx->id==$workorder->firmid){echo "selected";}?> value="<?=$firmx->id;?>"><?=$firmx->name;?></option>
									 <?}?>
								</select>
							</fieldset>
						</div>
						<?}else{?>
							<input type="hidden" class="form-control" id="firm2" name="Conformity[firmid]" value="<?=$ax->firmid;?>" requred>
						<?}?>
						
						<?if($ax->branchid==0){?>
						<div class="col-xl-12 col-lg-12 col-md-12 mb-1">
						<label for="basicSelect"><?=t('Branch');?></label>
							<fieldset class="form-group">
								<select class="select2" style="width:100%" id="branch2" name="Conformity[branchid]" onchange="mybranch2()" requred>
									<option value="0"><?=t('Please Chose');?></option>
									
									<?
									if($workorder->firmid!=0){
									$branch=Firm::model()->findall(array('condition'=>'parentid='.$workorder->firmid));
									 foreach($branch as $branchx){?>
									<option <?if($branchx->id==$workorder->branchid){echo "selected";}?> value="<?=$branchx->id;?>"><?=$branchx->name;?></option>
									<?}}?>
								</select>
							</fieldset>
						</div>
						<?}else{?>
							<input type="hidden" class="form-control" id="branch2" name="Conformity[branchid]" value="<?=$ax->branchid;?>" requred>
						<?}?>
					
					<?if($ax->clientid==0){?>					
					<div class="col-xl-12 col-lg-12 col-md-12 mb-1">
					<label for="basicSelect"><?=t('Client');?></label>
                        <fieldset class="form-group">
						
                          <select class="select2" style="width:100%" id="client2" name="Conformity[clientid]" requred onchange="myFunctionClient2()">
								<option value="0">Select</option>
								<?
								if($workorder->branchid!=0){
								$client=Client::model()->findall(array('condition'=>'parentid=0 and firmid='.$workorder->branchid));
								
									foreach($client as $clientx)
										{?>
											<optgroup label="<?=$clientx->name;?>">
												<?$clientbranchs=Client::model()->findAll(array('condition'=>'parentid='.$clientx->id));
													
													foreach($clientbranchs as $clientbranch)
													{?>
														<option <?if($clientbranch->id==$workorder->clientid){echo "selected";}?> value="<?=$clientbranch->id;?>"><?=$clientbranch->name;?></option>
													<?}?>
											</optgroup>
								<?}}?>
							</select>
                        </fieldset>
                    </div>
					<?}else{?>
							<input type="hidden" class="form-control" id="client2" name="Conformity[clientid]" value="<?=$ax->branchid;?>" requred>
					<?}?>

					
					
						<div class="col-xl-12 col-lg-12 col-md-12 mb-1">
						<label for="basicSelect"><?=t('Department');?></label>
							<fieldset class="form-group">
								<select class="select2" style="width:100%" id="department2" name="Conformity[departmentid]" onchange="myFunctionDepartment2()" requred>
									<option value="0"><?=t('Please Chose');?></option>
									
									<?
									if($workorder->firmid!=0){
									$branch=Firm::model()->findall(array('condition'=>'parentid='.$workorder->firmid));
									 foreach($branch as $branchx){?>
									<option <?if($branchx->id==$workorder->branchid){echo "selected";}?> value="<?=$branchx->id;?>"><?=$branchx->name;?></option>
									<?}}?>
								</select>
							</fieldset>
						</div>
						
						
					<div class="col-xl-12 col-lg-12 col-md-12 mb-1">
						<label for="basicSelect"><?=t('Sub-department');?></label>
							<fieldset class="form-group">
								<select class="select2" style="width:100%" id="subdepartment2" name="Conformity[subdepartmentid]" requred>
									<option value="0"><?=t('Please Chose');?></option>
									
									<?
									if($workorder->firmid!=0){
									$branch=Firm::model()->findall(array('condition'=>'parentid='.$workorder->firmid));
									 foreach($branch as $branchx){?>
									<option <?if($branchx->id==$workorder->branchid){echo "selected";}?> value="<?=$branchx->id;?>"><?=$branchx->name;?></option>
									<?}}?>
								</select>
							</fieldset>
						</div>


					<?
					$type=Conformitytype::model()->findAll(array(
								   #'select'=>'',
								   #'limit'=>'5',
								   'order'=>'name ASC',
								   'condition'=>'isactive=1',
							   ));
							   
					?>
					<div class="col-xl-12 col-lg-12 col-md-12 mb-1">
					 <label for="basicSelect"><?=t('Non-Conformity Type');?></label>
                       <fieldset class="form-group">
						  <select class="select2" id="modaltype" style="width:100%"  name="Conformity[type]">
                            <option value="0" selected=""><?=t('Please Chose');?></option>
							
							<?
								foreach($type as $typex){?>
									<option value="<?=$typex->id;?>"><?=t($typex->name);?></option>
							<?}?>
                        
                          </select>
                        </fieldset>
                    </div>
					
					<div class="col-xl-12 col-lg-12 col-md-12 mb-1">
					 <label for="basicSelect"><?=t('Non-Conformity Status');?></label>
                       <fieldset class="form-group">
						  <select class="select2" id="modalstatusid" style="width:100%"  name="Conformity[statusid]">
                          </select>
                        </fieldset>
                    </div>
					
					<div class="col-xl-12 col-lg-12 col-md-12 mb-1">
					<label for="basicSelect"><?=t('Priority');?></label>
                        <fieldset class="form-group">
						
                          <select class="select2" style="width:100%" id="modalpriority" name="Conformity[priority]">
								<option value="1"><?=t('1. Degree');?></option>
								<option value="2"><?=t('2. Degree');?></option>
								<option value="3"><?=t('3. Degree');?></option>
								<option value="4"><?=t('4. Degree');?></option>
							</select>
                        </fieldset>
                    </div>

					<div class="col-xl-12 col-lg-12 col-md-12 mb-1">
                        <fieldset class="form-group">
						<label for="basicSelect"><?=t('Date');?></label>
                          <input type="date"  class="form-control"  placeholder="<?=t('Date');?>" name="Conformity[date]" id="modaldate">
                        </fieldset>
                    </div>
					
					<div class="col-xl-12 col-lg-12 col-md-12 mb-1">
					<div id="img"></div>
                        <fieldset class="form-group">
						<label for="basicSelect"><?=t('Upload File');?></label>
                          <input type="file"  class="form-control"  name="Conformity[filesf]">
                        </fieldset>
                    </div>
				<input type="hidden"  class="form-control"  name="Conformity[filesfx]" id="modalfilesf">
		
					<div class="col-xl-12 col-lg-12 col-md-12 mb-1">
                        <fieldset class="form-group">
						<label for="basicSelect"><?=t('Definition');?></label>
                          <textarea  class="form-control"  placeholder="<?=t('Definition');?>" id="modaldefinition" name="Conformity[definition]"></textarea>
                        </fieldset>
                    </div>

					<div class="col-xl-12 col-lg-12 col-md-12 mb-1">
                        <fieldset class="form-group">
						<label for="basicSelect"><?=t('Suggestion / Preventative Action');?></label>
                          <textarea  class="form-control"  placeholder="<?=t('Suggestion / Preventative Action');?>" name="Conformity[suggestion]" id="modalsuggestion"></textarea>
                        </fieldset>
                    </div>
					
							
                            </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal"><?=t('Close');?></button>
                                 <button class="btn btn-warning block-page" type="submit"><?=t('Update');?></button>
                                </div>
								
						</form>
									
									<!--form bitiş-->
                    </div>
                </div>
            </div>
        </div>
    </div>
	
	<?}?>
	<!-- GÜNCELLEME BİTİŞ-->

		<!--SİL BAŞLANGIÇ-->
	<?php if (Yii::app()->user->checkAccess('nonconformitymanagement.delete')){ ?>
		<div class="col-lg-4 col-md-6 col-sm-12">
        <div class="form-group">
                           <!-- Modal -->
            <div class="modal fade text-left" id="sil" tabindex="-1" role="dialog" aria-labelledby="myModalLabel8"
                          aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header bg-danger white">
                            <h4 class="modal-title" id="myModalLabel8"><?=t('Activity Delete');?></h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
                            </button>
                        </div>
						
					<!--form baslangıç-->						
						<form id="user-form" action="/conformity/delete/0" method="post">	
						
					 <input type="hidden" class="form-control" id="modalid2" name="Conformity[id]" value="0">
					 <input type="hidden"  class="form-control"  name="Conformity[filesfx]" id="modalfile">
								
                            <div class="modal-body">
							
								<div class="col-xl-12 col-lg-12 col-md-12 mb-1">
									<h5> <?=t('Do you want to delete?');?></h5>
								</div>
				
								
					
                            </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal"><?=t('Close');?></button>
                                 <button class="btn btn-danger block-page" type="submit"><?=t('Delete');?></button>
                                </div>
								
						</form>
									
									<!--form bitiş-->
                    </div>
                </div>
            </div>
        </div>
    </div>
					  
	<!-- SİL BİTİŞ -->

	<!--delelete all start-->
	
		<div class="col-lg-4 col-md-6 col-sm-12">
        <div class="form-group">
                           <!-- Modal -->
            <div class="modal fade text-left" id="deleteall" tabindex="-1" role="dialog" aria-labelledby="myModalLabel8"
                          aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header bg-danger white">
                            <h4 class="modal-title" id="myModalLabel8"><?=t('Non-Conformity Delete');?></h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
                            </button>
                        </div>
						
				<!--form baslangıç-->						
						<form action="/conformity/deleteall" method="post">	
						
						<input type="hidden" class="form-control" id="modalid3" name="Conformity[id]" value="0">
								
                            <div class="modal-body">
							
								<div class="col-xl-12 col-lg-12 col-md-12 mb-1">
									<h5><?=t('Are you sure you want to delete?');?></h5>
								</div>
				
								
					
                            </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn grey btn-outline-secondary " data-dismiss="modal"><?=t('Close');?></button>
                                 <button class="btn btn-danger block-page" type="submit"><?=t('Delete');?></button>
                                </div>
								
						</form>
									
									<!--form bitiş-->
                    </div>
                </div>
            </div>
        </div>
    </div>
	
	<!-- delete all finish -->

<?}?>
<?}?>

<script>
// $("#reports").hide();


$("#printbutton").click(function(){
	var formdata= $("#conformity-form").serialize();
	var formElement = document.getElementById("conformity-form");
	
		formElement.target="_blank";
        formElement.action="<?=Yii::app()->getbaseUrl(true)?>/conformity/print/";
	
        formElement.submit();

		formElement.target="";
		formElement.action="/conformity/reports";
    //    var request = new XMLHttpRequest();
    
});


 $("#cancel").click(function(){
        $("#reports").hide(500);
 });

 $("#reportbutton").click(function(){
        $("#reports").toggle(500);
 });


 

 //delete all start
$(document).ready(function(){
    $('#select_all').on('click',function(){
        if(this.checked){
            $('.sec').each(function(){
                this.checked = true;
            });
        }else{
             $('.sec').each(function(){
                this.checked = false;
            });
        }
    });
    
    $('.sec').on('click',function(){
        if($('.sec:checked').length == $('.sec').length){
            $('#select_all').prop('checked',true);
        }else{
            $('#select_all').prop('checked',false);
        }
    });
});

 function deleteall()
 {
	var ids = [];
	$('.sec:checked').each(function(i, e) {
		ids.push($(this).val());
	});
	$('#modalid3').val(ids);
	if(ids=='')
	 {
		alert("<?=t('You must select at least one of the checboxes!');?>");
	}
	else
	 {
		$('#deleteall').modal('show');
	 }

 }
 // delete all finish

  $(document).ready(function() {
      $('.block-page').on('click', function() {
        $.blockUI({
            message: '<div class="ft-refresh-cw icon-spin font-medium-2"></div>',
            timeout: 20000, //unblock after 20 seconds
            overlayCSS: {
                backgroundColor: '#FFF',
                opacity: 0.8,
                cursor: 'wait'
            },
            css: {
                border: 0,
                padding: 0,
                backgroundColor: 'transparent'
            }
        });
    });

});
 
<?if($ax->firmid!=0){?>
	$( "#branch" ).prop( "disabled", false );
	$.post( "/workorder/firmbranch?id="+document.getElementById("firm").value).done(function( data ) {
		$( "#branch" ).prop( "disabled", false );
		$('#branch').html(data);
		//$("#"+$(obj).data('id')+"x").css("background-color", "yellow");
	
	});
<?}?>

<?if($ax->branchid!=0){?>
	$.post( "/workorder/client?id="+document.getElementById("branch").value).done(function( data ) {
		$( "#client" ).prop( "disabled", false );
		$('#client').html(data);
	});
<?}?>

<?if($ax->clientid!=0){?>
	$.post( "/workorder/clientb?id=<?=$ax->clientid;?>").done(function( data ) {
		$( "#client" ).prop( "disabled", false );
		$('#client').html(data);
	});
<?}?>


<?if($ax->clientbranchid!=0){?>
		$.post( "/conformity/client?id="+document.getElementById("client").value).done(function( data ) {
		$( "#department" ).prop( "disabled", false );
		$('#department').html(data);
		//$("#"+$(obj).data('id')+"x").css("background-color", "yellow");
	});
	
	$.post( "/conformity/conformitytype?id="+document.getElementById("client").value+'&&branch='+document.getElementById("branch").value+'&&firm='+document.getElementById("firm").value).done(function( data ) {
		$( "#conformitytype" ).prop( "disabled", false );
		$('#conformitytype').html(data);
	});
	
	
<?}?>



function myfirm() 
{
  $.post( "/workorder/firmbranch?id="+document.getElementById("firm").value).done(function( data ) {
		$( "#branch" ).prop( "disabled", false );
		$('#branch').html(data);
		//$("#"+$(obj).data('id')+"x").css("background-color", "yellow");
	
	});
}



 function mybranch() 
{
	$.post( "/workorder/client?id="+document.getElementById("branch").value).done(function( data ) {
		$( "#client" ).prop( "disabled", false );
		$('#client').html(data);
	});
}







function myFunctionClient() {

  	$.post( "/conformity/client?id="+document.getElementById("client").value).done(function( data ) {
		$( "#department" ).prop( "disabled", false );
		$('#department').html(data);
		//$("#"+$(obj).data('id')+"x").css("background-color", "yellow");
	
	});
	
	$.post( "/conformity/conformitytype?id="+document.getElementById("client").value+'&&branch='+document.getElementById("branch").value+'&&firm='+document.getElementById("firm").value).done(function( data ) {
		$( "#conformitytype" ).prop( "disabled", false );
		$('#conformitytype').html(data);
	});
	
}



<?if(isset($_POST['Reports']['firmid'])){?>

	$("#reports").show();


	  $.post( "/workorder/firmbranch?id=<?=$_POST['Reports']['firmid'];?>").done(function( data ) {
		$( "#branch" ).prop( "disabled", false );
		$('#branch').html(data);

		<?if(isset($_POST['Reports']['branchid'])){?>

			$('#branch').val(<?=$_POST['Reports']['branchid'];?>);
			$('#branch').select2('destroy');
			$('#branch').select2({
				closeOnSelect: false,
				allowClear: true
			});

			<?}?>
	});
<?}?>



<?if(isset($_POST['Reports']['branchid'])){?>
	 	$.post( "/workorder/client?id=<?=$_POST['Reports']['branchid'];?>").done(function( data ) {
		$( "#client" ).prop( "disabled", false );
		$('#client').html(data);
	
		<?if(isset($_POST['Reports']['clientid'])){?>

			$('#client').val(<?=$_POST['Reports']['clientid'];?>);
			$('#client').select2('destroy');
			$('#client').select2({
				closeOnSelect: false,
				allowClear: true
			});

			<?}?>
	});
<?}?>



function myFunctionDepartment() {
  	$.post( "/conformity/department?id="+document.getElementById("department").value).done(function( data ) {
		$( "#subdepartment" ).prop( "disabled", false );
		$('#subdepartment').html(data);
		//$("#"+$(obj).data('id')+"x").css("background-color", "yellow");
	
	});
}


/*


function myfirm2() 
{
  $.post( "/workorder/firmbranch?id="+document.getElementById("firm2").value).done(function( data ) {
		$( "#branch2" ).prop( "disabled", false );
		$('#branch2').html(data);
		//$("#"+$(obj).data('id')+"x").css("background-color", "yellow");
	
	});
}

 function mybranch2() 
{
	$.post( "/workorder/client?id="+document.getElementById("branch2").value).done(function( data ) {
		$( "#client2" ).prop( "disabled", false );
		$('#client2').html(data);
	});
}


function myFunctionClient2() {
  	$.post( "/conformity/client?id="+document.getElementById("client2").value).done(function( data ) {
		$( "#department2" ).prop( "disabled", false );
		$('#department2').html(data);
		//$("#"+$(obj).data('id')+"x").css("background-color", "yellow");
	
	});
}

function myFunctionDepartment2() {
  	$.post( "/conformity/department?id="+document.getElementById("department2").value).done(function( data ) {
		$( "#subdepartment2" ).prop( "disabled", false );
		$('#subdepartment2').html(data);
		//$("#"+$(obj).data('id')+"x").css("background-color", "yellow");
	
	});
}

 

 function openmodal(obj)
{
	$('#firm2').val($(obj).data('firmid'));
	
	  $.post( "/workorder/firmbranch?id="+$(obj).data('firmid')).done(function( data ) {
		$( "#branch2" ).prop( "disabled", false );
		$('#branch2').html(data);
		$('#branch2').val($(obj).data('branchid'));
		//$("#"+$(obj).data('id')+"x").css("background-color", "yellow");
	});
	$.post( "/workorder/client?id="+$(obj).data('branchid')).done(function( data ) {
		$( "#client2" ).prop( "disabled", false );
		$('#client2').html(data);
		$('#client2').val($(obj).data('clientid'));
	});
	$.post( "/conformity/client?id="+$(obj).data('clientid')).done(function( data ) {
		$( "#department2" ).prop( "disabled", false );
		$('#department2').html(data);
		$('#department2').val($(obj).data('departmentid'));
	});
	$.post( "/conformity/department?id="+$(obj).data('departmentid')).done(function( data ) {
		$( "#subdepartment2" ).prop( "disabled", false );
		$('#subdepartment2').html(data);
		$('#subdepartment2').val($(obj).data('subdepartmentid'));
	});
	
	$.post( "/conformity/conformitytype?id="+$(obj).data('clientid')+'&&branch='+$(obj).data('branchid')+'&&firm='+$(obj).data('firmid')).done(function( data ) {
		$( "#modaltype" ).prop( "disabled", false );
		$('#modaltype').html(data);
		$('#modaltype').val($(obj).data('type'));
	});
	
	$.post( "/conformity/conformitystatus?id="+$(obj).data('clientid')+'&&branch='+$(obj).data('branchid')+'&&firm='+$(obj).data('firmid')).done(function( data ) {
		$( "#modalstatusid" ).prop( "disabled", false );
		$('#modalstatusid').html(data);
		$('#modalstatusid').val($(obj).data('statusid'));
	});
	

										 
	$('#modalid').val($(obj).data('id'));
	
	
	
	
	$('#modaldefinition').val($(obj).data('definition'));
	$('#modalsuggestion').val($(obj).data('suggestion'));
	$('#modalstatusid').val($(obj).data('statusid'));
	$('#modalpriority').val($(obj).data('priority'));
	$('#modaldate').val($(obj).data('date'));
	$('#modalfilesf').val($(obj).data('filesf'));
	$('#duzenle').modal('show');
	
}


 function openmodalsil(obj)
{
	$('#modalid2').val($(obj).data('id'));
	$('#modalfile').val($(obj).data('file'));
	$('#sil').modal('show');
	
}
*/

$(document).ready(function() {


	// Multiple Select Placeholder
    $(".select2-placeholder-multiple").select2({
      placeholder: "<?=t('Select State');?>",
    });

/******************************************
*       js of HTML5 export buttons        *
******************************************/

<?$whotable=User::model()->iswhotable();
$whotable->name='';?>

$('.dataex-html5-export').DataTable( {
    dom: 'Bfrtip',
	    language: {
        buttons: {
            pageLength: {
                _: "<?=t('Show');?> %d <?=t('rows');?>",
                '-1': "<?=t('Tout afficher');?>"
            },
			colvis: "<?=t('Columns Visibility');?>",
        },
				     "sDecimal": ",",
                     "sEmptyTable": "<?=t('Data is not available in the table');?>",
                     //"sInfo": "_TOTAL_ kayıttan _START_ - _END_ arasındaki kayıtlar gösteriliyor",
                     "sInfo": "<?=t('Total number of records');?> : _TOTAL_",
                     "sInfoEmpty": "<?=t('No records found');?> ! ",
                     "sInfoFiltered": "(_MAX_ <?=t('records');?>)",
                     "sInfoPostFix": "",
                     "sInfoThousands": ".",
                     "sLengthMenu": "<?=t('Top of page');?> _MENU_ <?=t('record');?>",
                     "sLoadingRecords": "<?=t('Loading');?>...",
                     "sProcessing": "<?=t('Processing');?>...",
                     "sSearch": "<?=t('Search');?>:",
                     "sZeroRecords": "<?=t('No records found');?> !",
                     "oPaginate": {
                         "sFirst": "<?=t('First page');?>",
                         "sLast": "<?=t('Last page');?>",
                         "sNext": "<?=t('Next');?>",
                         "sPrevious": "<?=t('Previous');?>"
                     },
    },
	"columnDefs": [ {
	"searchable": false,
	"orderable": false,
	// "targets": 0
	} ],
	"order": [[ 4, 'desc' ]],

	 buttons: [
		  <?if($yetki==1){?>
        {

		
            extend: 'copyHtml5',
            exportOptions: {
                columns: [ 0,1]
            },
			text:'<?=t('Copy');?>',
			className: 'd-none d-sm-none d-md-block',
			title:'Non-Conformity (<?=date('d-m-Y H:i:s');?>)',
			messageTop:'<?=$exel;?>'
        },

		


        {
            extend: 'excelHtml5',
            
			text:'<?=t('Excel');?>',
			className: 'd-none d-sm-none d-md-block',
			title:'Non-Conformity (<?=date('d-m-Y H:i:s');?>)',
			messageTop:'<?=$exel;?>'
		 },
        {
             extend: 'pdfHtml5',
			 orientation: 'landscape',
			  //message: "Made: 20_05-17\nMade by whom: User232\n" + "Custom message",
			   exportOptions: {
               columns: [ 0,1,3,4,5,6,7]
            },

			


				
			  text:'<?=t('PDF');?>',
			  title: 'Export',

			  action: function ( e, dt, node, config ) {
                   /* window.location = '/conformity/print'; */

					var formdata= $("#conformity-form").serialize();
					var formElement = document.getElementById("conformity-form");
					
						formElement.target="_blank";
						formElement.action="<?=Yii::app()->getbaseUrl(true)?>/conformity/print/";
					
						formElement.submit();

						formElement.target="";
						formElement.action="/conformity/reports";
					//    var request = new XMLHttpRequest();
                },
			  header: true,
			  customize: function(doc) {
				doc.content.splice(0, 1, {
				  text: [{
					text: 'Non-Conformity \n',
					bold: true,
					fontSize: 16,
						alignment: 'center'
				  }, 
				 {
					text: '<?=$exel;?>\n',
					bold: true,
					fontSize: 12,
						alignment: 'center'
				  }, 
					
						{
					text: '<?=date('d-m-Y H:i:s');?>',
					bold: true,
					fontSize: 11,
					alignment: 'center'
				  }],
				  margin: [0, 0, 0, 12]
				  
				});
			  }

        },

			<?}?>
        'colvis',
		'pageLength'
    ]
	

} );
} );


</script>		 
 <?php
 
 Yii::app()->params['scripts'].=Yii::app()->theme->baseUrl.'/app-assets/vendors/js/forms/icheck/icheck.min.js;';
Yii::app()->params['scripts'].=Yii::app()->theme->baseUrl.'/app-assets/js/scripts/forms/checkbox-radio.js;';

Yii::app()->params['css'].=Yii::app()->theme->baseUrl.'/app-assets/vendors/css/forms/icheck/icheck.css;';


Yii::app()->params['scripts'].=Yii::app()->theme->baseUrl.'/app-assets/vendors/js/forms/select/select2.full.min.js;';
Yii::app()->params['scripts'].=Yii::app()->theme->baseUrl.'/app-assets/js/scripts/forms/select/form-select2.js;';



Yii::app()->params['scripts'].=Yii::app()->theme->baseUrl.'/app-assets/vendors/js/tables/datatable/datatables.min.js;';
Yii::app()->params['scripts'].=Yii::app()->theme->baseUrl.'/app-assets/vendors/js/tables/datatable/dataTables.buttons.min.js;';
Yii::app()->params['scripts'].=Yii::app()->theme->baseUrl.'/app-assets/vendors/js/tables/datatable/buttons.bootstrap4.min.js;';



Yii::app()->params['css'].=Yii::app()->theme->baseUrl.'/app-assets/vendors/css/tables/datatable/datatables.min.css;';
Yii::app()->params['css'].=Yii::app()->theme->baseUrl.'/app-assets/vendors/css/tables/extensions/buttons.dataTables.min.css;';
Yii::app()->params['css'].=Yii::app()->theme->baseUrl.'/app-assets/vendors/css/tables/datatable/buttons.bootstrap4.min.css;';


Yii::app()->params['css'].=Yii::app()->theme->baseUrl.'/app-assets/vendors/css/forms/selects/select2.min.css;';
Yii::app()->params['css'].=Yii::app()->theme->baseUrl.'/app-assets/css/app.css;';


Yii::app()->params['css'].=Yii::app()->theme->baseUrl.'/app-assets/vendors/css/pickers/daterange/daterangepicker.css;';
Yii::app()->params['css'].=Yii::app()->theme->baseUrl.'/app-assets/vendors/css/pickers/datetime/bootstrap-datetimepicker.css;';

?>