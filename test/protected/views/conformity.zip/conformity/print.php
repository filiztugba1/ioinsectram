<?php 

User::model()->login();
$ax= User::model()->userobjecty('');

$exel='';

	if($ax->firmid>0)
	{
		$exel=Firm::model()->find(array('condition'=>'id='.$ax->firmid))->name;
		if($ax->branchid>0)
		{
			$exel=$exel.' > '.Firm::model()->find(array('condition'=>'id='.$ax->branchid))->name;
			if($ax->clientid>0)
			{
				$exel=$exel.' > '.Client::model()->find(array('condition'=>'id='.$ax->clientid))->name;
				if($ax->clientbranchid>0)
				{
					$exel=$exel.' > '.Client::model()->find(array('condition'=>'id='.$ax->clientbranchid))->name;
					$where="clientid=".$ax->clientbranchid;
					
					
				}
				else
				{					
					$where="clientid in (".implode(',',Client::model()->getbranchids($ax->clientid)).")";
		
					/*	$workorder=Client::model()->findAll(array('condition'=>'parentid='.$ax->clientid));
						$i=0;
						foreach($workorder as $workorderx)
						{
							if($i==0)
							{
								$where='clientid='.$workorderx->id;
							}
							else
							{
							$where=$where.' or clientid='.$workorderx->id;
							}
											
						}*/
					
					
				}
			}
			else
			{
				$where="firmbranchid=".$ax->branchid;
			}
		}
		else
		{
			$where="firmid in (".implode(',',Firm::model()->getbranchids($ax->firmid)).")";
		}


		$where=$where." and endofdayemail=0";
		
	}
	else
	{
		$where="endofdayemail=0";
	}


if(isset($_POST['Reports']['firmid']) && $_POST['Reports']['firmid']!='')
{
	$exel=Firm::model()->find(array('condition'=>'id='.$_POST['Reports']['firmid']))->name;
	$where="firmid in (".implode(',',Firm::model()->getbranchids($_POST['Reports']['firmid'])).")";
}

if(isset($_POST['Reports']['branchid']) && $_POST['Reports']['branchid']!='')
{
	$exel=$exel.' > '.Firm::model()->find(array('condition'=>'id='.$_POST['Reports']['branchid']))->name;

	$where="firmbranchid=".$_POST['Reports']['branchid'];
}


if(isset($_POST['Reports']['clientid']) && $_POST['Reports']['clientid']!='')
{
	$clb=Client::model()->find(array('condition'=>'id='.$_POST['Reports']['clientid']));
	$cl=Client::model()->find(array('condition'=>'id='.$clb->parentid));
	
	$exel=$exel.' > '.$cl->name.' > '.$clb->name;
	
	$where="clientid=".$_POST['Reports']['clientid'];
}






if(isset($_POST['Reports']['type']) && $_POST['Reports']['type']!=-1)
{
	
	$statussql='';
	$statusexel='';

	for($i=0;$i<count($_POST["Reports"]["type"]);$i++)
	{
		$stname=Conformitystatus::model()->find(array('condition'=>'id='.$_POST["Reports"]["type"][$i]));
		if($i==0)
		{
			$statussql='statusid='.$_POST["Reports"]["type"][$i];
			$statusexel=$stname->name;
		}
		else
		{
			$statussql=$statussql.' or statusid='.$_POST["Reports"]["type"][$i];
			$statusexel=$statusexel.','.$stname->name;
		}

		
		$exel=$exel.' ( '.t("Status").'='.$statusexel.')';
		
	}

	$where= $where." and (".$statussql.')';

}

if(isset($_POST['Reports']['startdate'])) 
{
	$midnight = strtotime("today", strtotime($_POST['Reports']['startdate']));
	$where= $where." and date>=".$midnight;

	$exel=$exel.'( '.t("Start Date").'='.$_POST['Reports']['startdate'].')';
}

if(isset($_POST['Reports']['finishdate'])) 
{
	$midnight2 = strtotime("today", strtotime($_POST['Reports']['finishdate'])+3600*24);
	$where= $where." and date<=".$midnight2;

	$exel=$exel.'( '.t("Finish Date").'='.$_POST['Reports']['finishdate'].')';
}
//echo $where;




		$conformity=Conformity::model()->findAll(array('condition'=>$where,'order'=>'statusid asc'));

$yaz="";

			foreach($conformity as $conformityx){
			$deadline=Conformityactivity::model()->find(array('condition'=>'conformityid='.$conformityx->id));
			$effincy=Efficiencyevaluation::model()->find(array('condition'=>'conformityid='.$conformityx->id));
			
			if($effincy)
			{
				$eff=$effincy->controldate;
			}
			else{
				$eff='No';
			}
				if($deadline)
				{
					$deadt=$deadline->date;
				}
				else{
					$deadt="-";
				}
			$depart=Departments::model()->find(array('condition'=>'id='.$conformityx->departmentid,));
			if ($depart){ $depart=$depart->name;
			$subdep=Departments::model()->find(array('condition'=>'id='.$conformityx->subdepartmentid,))->name;
			}else{
			$depart='-';
			$subdep='-';
			
			}
			if($conformityx->closedtime!='')
				{
					$kpnma=date('Y-m-d',$conformityx->closedtime);
				}
				else{
					$kpnma="-";
				}

			$username=User::model()->find(array('condition'=>'id='.$conformityx->userid));

			if($conformityx->filesf)
			{
				$resim="<img src='".Yii::app()->getbaseUrl(true)."/".$conformityx->filesf."' width='200px' height='200px' >";
				
			}
			else{
				$resim="";
			}
		


				$yaz .="
			<tr>
			
				 <td>".$username->name." ".$username->surname."</td>
				 <td>".Client::model()->find(array('condition'=>'id='.$conformityx->clientid))->name."</td>
	<td>".$depart."</td>
				 <td>".$subdep."</td>
				 <td>
				 ".date('Y-m-d',$conformityx->date)."
				 <td>".t(Conformitytype::model()->find(array('condition'=>'id='.$conformityx->type,))->name)."</td>
				
			
				
				 <td>".$conformityx->definition."</td> 
				 <td>".$conformityx->suggestion."</td>
				 <td>".t(Conformitystatus::model()->find(array('condition'=>'id='.$conformityx->statusid,))->name)."</td>
				
				<td>".$conformityx->priority."".t('st Degree')."</td> 
				<td>".$deadt."</td>  
				<td>".$kpnma."</td>
				<td>".t($eff)."</td>	
				<td>".$resim."</td>
				
		
	   </tr>";
						}
		


$html="<html><head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'></head><body><style>
.f12
{
	font-size:12px;
}td,th{
	border:1px solid #333333;

}
th {
font-family:Arial;
}
td {
font-family:Arial;
}
</style><table border='0'  width='100%' cellpadding='0' cellspacing='0'>
                        <thead>
                          <tr>
					
							<th>".t('WHO')."</th>
                            <th>".t('TO WHO')."</th>
                            <th>".t('DEPARTMENT')."</th>
                            <th>".t('SUB-DEPARTMENT')."</th>
                            <th>".t('OPENING DATE')."</th>
                            <th>".t('TYPE')."</th>
                            <th>".t('DEFINITION')."</th>
                            <th>".t('SUGGESTION')."</th>
                            <th>".t('STATUS')."</th>
                            <th>".t('PRIORITY')."</th>
							<th>".t('DEADLINE')."</th>
							<th>".t('CLOSED TIME')."</th>
							<th>".t('ACTIVITY STATUS')."</th>
							<th>".t('IMAGE')."</th>

						
							
                          </tr>
                        </thead>
                        <tbody>
                         ".$yaz."
                     
					 		
						 
                        </tbody>
                      </table>";


					  ?>